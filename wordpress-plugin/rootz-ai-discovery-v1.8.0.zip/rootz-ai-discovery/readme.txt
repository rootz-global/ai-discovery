=== Rootz AI Discovery ===
Contributors: rootzcorp
Tags: ai, discovery, ai-discovery, ai-agent, machine-readable, webmcp, llms-txt, content-api
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 2.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Make your WordPress site AI-agent-ready. Structured identity, machine-readable policies, content API, and WebMCP tools in one install.

== Description ==

When an AI agent visits your WordPress site today, it has to scrape HTML, guess your organization, and parse legal pages written for humans. **Rootz AI Discovery** fixes this by serving structured, machine-readable data that AI agents can understand instantly.

**What it does:**

* Serves `/.well-known/ai` with your organization identity, capabilities, and policies (RFC 8615)
* Structured content endpoint at `/.well-known/ai/content` with pages, posts, media, custom types
* Auto-generates knowledge base at `/.well-known/ai/knowledge`
* AI-optimized content feed at `/.well-known/ai/feed`
* Adds `<link rel="ai-discovery">` tag and HTTP Link header to every page
* Generates `/llms.txt` from your site structure
* Provides REST API endpoints for AI agents (`/wp-json/rootz/v1/`)
* Registers WebMCP tools for browser-based AI assistants (Chrome 146+)
* Machine-readable content licensing (CC-BY, CC0, All Rights Reserved, etc.)
* AI training opt-in/opt-out declaration
* Digital identity support (blockchain wallet address, network, identity contract)
* Content assertion types (factual, editorial, creative-work) per item

**No external API calls.** Everything runs locally on your WordPress site. Zero tracking, zero analytics, zero phoning home.

**Open standard.** The AI Discovery Standard v1.2 is CC-BY-4.0 licensed. Learn more at [rootz.global/ai-discovery](https://rootz.global/ai-discovery).

== Installation ==

1. Upload the `rootz-ai-discovery` folder to `/wp-content/plugins/`
2. Activate the plugin through the Plugins menu
3. Go to Settings → AI Discovery to customize your organization info
4. Visit `yoursite.com/.well-known/ai` to verify it's working
5. Scan your site at [rootz.global/ai-discovery](https://rootz.global/ai-discovery) to check your score

== Frequently Asked Questions ==

= Does this slow down my site? =

No. The plugin serves cached JSON responses and adds a single `<link>` tag to your HTML head. The WebMCP script is ~4KB and loads asynchronously.

= Does it send data to external servers? =

No. Everything is generated locally from your WordPress data. Zero external API calls.

= What is the AI Discovery Standard? =

An open specification (CC-BY-4.0) for how websites should present structured information to AI agents. Think of it as "robots.txt for AI identity" — but instead of blocking, it enables proper interaction. See [rootz.global/ai-discovery](https://rootz.global/ai-discovery).

= What is the content endpoint? =

The content endpoint at `/.well-known/ai/content` serves your pages, posts, media, and custom post types as structured JSON so AI agents can understand your site without scraping HTML. Each item includes an assertion type (factual, editorial, creative-work) so agents know how to interpret the information.

= What is WebMCP? =

WebMCP is a browser API (Chrome 146+) that lets websites register tools with AI assistants. This plugin automatically registers tools like `getOrganizationInfo` and `getPolicies` so AI assistants can read your site's structured data.

= Do I need to flush permalinks after installation? =

The plugin does this automatically on activation. If `/.well-known/ai` returns a 404, go to Settings → Permalinks and click Save (this flushes rewrite rules).

== Changelog ==

= 2.0.1 =
* secp256k1 plugin wallet for cryptographic signing (AES-256-CBC encrypted storage)
* Wallet-authenticated AI proxy — auto-populate without user API key
* AI-powered identity extraction (legalName, sector, founded, headquarters)
* AI-generated site summary and core concepts
* Owner wallet delegation support
* Quick Start guide tab for new installs
* Analytics tab with AI access metrics
* 8-tab admin interface (Identity, Content, Policies, Tools, Viewer, Analytics, Account, Quick Start)
* Content endpoint with assertion types (factual, editorial, creative-work)
* REST API search, verify, and status scoring endpoints
* Admin manifest review workflow (approve changes before re-signing)

= 1.2.0 =
* v1.2 URL hierarchy: all endpoints under /.well-known/ai/ (RFC 8615)
* Content endpoint: /.well-known/ai/content with pages, posts, media, custom types
* Segmented content access: /content/pages, /content/posts, /content/media
* Content assertion types: factual, editorial, creative-work per item
* Full text option: serve complete post/page content (not just excerpts)
* Media support with EXIF data (camera, focal length, aperture, ISO)
* Digital identity: blockchain wallet address, network, identity contract
* Organization details: legal name, founded, headquarters, contact info
* AI summary and core concepts fields
* 4-tab admin: Identity, Content, Policies, Tools & Preview
* Toggleable tier endpoints (knowledge, feed, content)
* Dynamic endpoint status in Tools tab

= 0.1.0 =
* Initial release
* AI Discovery endpoint at /.well-known/ai
* HTML link tag and HTTP Link header
* Admin settings page (Identity, Policies, Tools tabs)
* REST API endpoints (ai.json, policies, knowledge, feed, tools)
* WebMCP tool registration (getOrganizationInfo, getPolicies, getKnowledge, getFeed)
* Auto-generated llms.txt
* Content licensing declarations
* AI training opt-in/opt-out

== Screenshots ==

1. Settings page — Identity tab with organization details and digital identity
2. Settings page — Content tab with endpoint configuration
3. Settings page — Policies tab with content licensing
4. Tools & Preview tab showing all v1.2 endpoints with status
5. ai.json output from /.well-known/ai

== Privacy ==

This plugin does not collect, store, or transmit any user data to external servers. All data is generated from your existing WordPress content and stored locally in wp_options.

The plugin does not use cookies, analytics, or tracking of any kind.

Future paid features may optionally connect to api.rootz.global for Digital Name signing and blockchain anchoring. This will always be opt-in with clear disclosure.
