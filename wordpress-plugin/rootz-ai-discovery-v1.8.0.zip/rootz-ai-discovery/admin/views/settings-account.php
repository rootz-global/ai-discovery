<?php
/**
 * Account & Signing settings tab — signing key, AI support, wallet identity.
 *
 * @package Rootz_AI_Discovery
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$has_gmp         = Rootz_Signer::has_gmp();
$signing_address = Rootz_Signer::stored_address();
$has_stored_key  = Rootz_Signer::has_stored_key();
$can_sign        = $has_gmp && $has_stored_key;
$wallet_address  = get_option( 'rootz_plugin_wallet', '' );
$auto_populate   = isset( $_GET['auto-populate'] ) && '1' === $_GET['auto-populate'];
$key_generated   = isset( $_GET['key-generated'] ) && '1' === $_GET['key-generated'];
$ai_api_key      = get_option( 'rootz_ai_api_key', '' );
?>

<div class="rootz-viewer-intro">
    <h2><?php esc_html_e( 'Account & Signing', 'rootz-ai-discovery' ); ?></h2>
    <p class="description">
        <?php esc_html_e( 'Your site\'s cryptographic identity and AI-powered content tools.', 'rootz-ai-discovery' ); ?>
    </p>
</div>

<?php // ── PLUGIN WALLET IDENTITY ──────────────────────────────────────── ?>
<?php if ( ! empty( $signing_address ) ) : ?>
<div class="rootz-viewer-card" style="border-left: 4px solid #2271b1; background: linear-gradient(135deg, #f0f6fc 0%, #fff 100%);">
    <div class="rootz-viewer-card-header">
        <h3>
            <span class="rootz-viewer-icon">&#128737;</span>
            <?php esc_html_e( 'Plugin Wallet', 'rootz-ai-discovery' ); ?>
            <?php Rootz_Admin::help_tip( __( 'Your site generates a cryptographic keypair (secp256k1) stored locally on your server. Every AI Discovery response is signed with this key, proving the data genuinely comes from your site and has not been tampered with. The private key is encrypted in your WordPress database using your wp-config.php salts.', 'rootz-ai-discovery' ), 'wallet' ); ?>
        </h3>
        <?php if ( $can_sign ) : ?>
            <span class="rootz-status-connected">&#9679; <?php esc_html_e( 'Signing Active', 'rootz-ai-discovery' ); ?></span>
        <?php else : ?>
            <span class="rootz-status-disconnected">&#9679; <?php esc_html_e( 'Read-Only (GMP needed to sign)', 'rootz-ai-discovery' ); ?></span>
        <?php endif; ?>
    </div>

    <?php if ( $key_generated ) : ?>
    <div class="rootz-viewer-hint" style="border-left-color: #00a32a; background: #f0faf0;">
        <?php esc_html_e( 'Signing key generated! Your AI Discovery data is now cryptographically signed.', 'rootz-ai-discovery' ); ?>
    </div>
    <?php endif; ?>

    <div style="margin: 16px 0; padding: 16px; background: #fff; border: 1px solid #c3c4c7; border-radius: 4px;">
        <div style="font-size: 11px; text-transform: uppercase; color: #646970; letter-spacing: 0.5px; margin-bottom: 6px;">
            <?php esc_html_e( 'Site Identity Address', 'rootz-ai-discovery' ); ?>
        </div>
        <code style="font-size: 15px; font-weight: 600; letter-spacing: 0.5px; word-break: break-all; display: block; padding: 8px 0;">
            <?php echo esc_html( $signing_address ); ?>
        </code>
        <div style="margin-top: 10px; display: flex; gap: 16px; font-size: 12px; color: #646970;">
            <span><?php esc_html_e( 'Algorithm: ECDSA secp256k1', 'rootz-ai-discovery' ); ?></span>
            <span>|</span>
            <span><?php esc_html_e( 'Network: Ethereum-compatible', 'rootz-ai-discovery' ); ?></span>
            <span>|</span>
            <span>
                <?php if ( $can_sign ) : ?>
                    <?php esc_html_e( 'Status: Self-signed', 'rootz-ai-discovery' ); ?>
                <?php else : ?>
                    <?php esc_html_e( 'Status: Hash-only (enable GMP to sign)', 'rootz-ai-discovery' ); ?>
                <?php endif; ?>
            </span>
        </div>
    </div>

    <p class="rootz-viewer-explain">
        <?php esc_html_e( 'This is your site\'s persistent cryptographic identity. It\'s an Ethereum-compatible address generated locally on your server. Every AI Discovery response includes this address, allowing AI agents to verify data authenticity and track your site\'s identity over time.', 'rootz-ai-discovery' ); ?>
    </p>

    <table class="rootz-viewer-table">
        <tbody>
            <tr>
                <td class="rootz-viewer-label"><?php esc_html_e( 'Private Key Storage', 'rootz-ai-discovery' ); ?></td>
                <td><?php esc_html_e( 'AES-256-CBC encrypted in database (key derived from wp-config.php salts)', 'rootz-ai-discovery' ); ?></td>
            </tr>
            <tr>
                <td class="rootz-viewer-label"><?php esc_html_e( 'Signing Capability', 'rootz-ai-discovery' ); ?></td>
                <td>
                    <?php if ( $can_sign ) : ?>
                        <span style="color: #00a32a;">&#10003;</span>
                        <?php esc_html_e( 'Active — every ai.json response is cryptographically signed', 'rootz-ai-discovery' ); ?>
                    <?php else : ?>
                        <span style="color: #996800;">&#9888;</span>
                        <?php esc_html_e( 'Inactive — PHP GMP extension not available. Content hashes are still included.', 'rootz-ai-discovery' ); ?>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td class="rootz-viewer-label"><?php esc_html_e( 'Authorization', 'rootz-ai-discovery' ); ?></td>
                <td>
                    <span class="rootz-viewer-tag"><?php esc_html_e( 'self-signed', 'rootz-ai-discovery' ); ?></span>
                    <span class="description" style="margin-left: 8px;">
                        <?php esc_html_e( 'Proves consistency. Link to your owner wallet for full authorization.', 'rootz-ai-discovery' ); ?>
                    </span>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<?php else : ?>
<?php // ── NO KEY YET ──────────────────────────────────────────────────── ?>
<div class="rootz-viewer-card">
    <div class="rootz-viewer-card-header">
        <h3>
            <span class="rootz-viewer-icon">&#128737;</span>
            <?php esc_html_e( 'Plugin Wallet', 'rootz-ai-discovery' ); ?>
        </h3>
        <?php if ( ! $has_gmp ) : ?>
            <span class="rootz-status-disconnected">&#9679; <?php esc_html_e( 'GMP Required', 'rootz-ai-discovery' ); ?></span>
        <?php else : ?>
            <span class="rootz-status-disconnected">&#9679; <?php esc_html_e( 'Not Generated', 'rootz-ai-discovery' ); ?></span>
        <?php endif; ?>
    </div>

    <?php if ( ! $has_gmp ) : ?>
    <div class="rootz-viewer-hint" style="border-left-color: #d63638; background: #fcf0f1;">
        <?php esc_html_e( 'The PHP GMP extension is required to generate a signing key. Most production WordPress hosts have GMP enabled. Contact your hosting provider if needed. The plugin still works without it — content hashes are included but not cryptographically signed.', 'rootz-ai-discovery' ); ?>
    </div>
    <?php endif; ?>

    <p class="rootz-viewer-explain">
        <?php esc_html_e( 'Generate a persistent wallet address for your site. This Ethereum-compatible keypair is created locally and signs every AI Discovery response, proving the data is authentic and hasn\'t been tampered with.', 'rootz-ai-discovery' ); ?>
    </p>

    <?php if ( $has_gmp ) : ?>
    <form method="post" action="">
        <?php wp_nonce_field( 'rootz_generate_key', 'rootz_generate_key_nonce' ); ?>
        <p>
            <button type="submit" name="rootz_do_generate_key" value="1" class="button button-primary button-hero">
                <?php esc_html_e( 'Generate Plugin Wallet', 'rootz-ai-discovery' ); ?>
            </button>
        </p>
        <p class="description">
            <?php esc_html_e( 'Creates a new secp256k1 keypair. This only needs to happen once — the address persists until you delete it.', 'rootz-ai-discovery' ); ?>
        </p>
    </form>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php // ── OWNER WALLET (AUTHORIZATION) ───────────────────────────────── ?>
<div class="rootz-viewer-card">
    <div class="rootz-viewer-card-header">
        <h3>
            <span class="rootz-viewer-icon">&#128176;</span>
            <?php esc_html_e( 'Owner Wallet (Authorization)', 'rootz-ai-discovery' ); ?>
        </h3>
    </div>

    <p class="rootz-viewer-explain">
        <?php esc_html_e( 'Your personal wallet address. When you authorize the signing key from this wallet (via on-chain transaction), the signature upgrades from "self-signed" to "delegated" — proving YOU authorized this site\'s AI Discovery data.', 'rootz-ai-discovery' ); ?>
    </p>

    <form method="post" action="options.php">
        <?php settings_fields( 'rootz_ai_discovery' ); ?>

        <table class="form-table" role="presentation">
            <tr>
                <th scope="row">
                    <label for="rootz_plugin_wallet"><?php esc_html_e( 'Owner Wallet', 'rootz-ai-discovery' ); ?></label>
                </th>
                <td>
                    <input type="text" id="rootz_plugin_wallet" name="rootz_plugin_wallet"
                           value="<?php echo esc_attr( $wallet_address ); ?>"
                           class="regular-text" placeholder="0x..." />
                    <p class="description">
                        <?php esc_html_e( 'Your MetaMask / epistery wallet address. Used for future authorization binding.', 'rootz-ai-discovery' ); ?>
                    </p>
                </td>
            </tr>
        </table>

        <?php submit_button( __( 'Save Wallet', 'rootz-ai-discovery' ) ); ?>
    </form>

    <?php if ( $has_stored_key && ! empty( $wallet_address ) ) : ?>
    <div class="rootz-viewer-hint">
        <strong><?php esc_html_e( 'Next step:', 'rootz-ai-discovery' ); ?></strong>
        <?php
        printf(
            esc_html__( 'To upgrade from self-signed to delegated, send an authorization transaction from %1$s to %2$s. This feature is coming in a future update.', 'rootz-ai-discovery' ),
            '<code>' . esc_html( substr( $wallet_address, 0, 10 ) ) . '...' . '</code>',
            '<code>' . esc_html( substr( $signing_address, 0, 10 ) ) . '...' . '</code>'
        );
        ?>
    </div>
    <?php endif; ?>
</div>

<?php // ── AI CONTENT GENERATION ───────────────────────────────────────── ?>
<?php
$ai_gen       = new Rootz_Ai_Generator();
$has_proxy    = $ai_gen->has_proxy();
$has_direct   = $ai_gen->has_direct();
$ai_available = $ai_gen->is_available();
$proxy_usage  = get_transient( 'rootz_proxy_usage' );
$proxy_error  = get_transient( 'rootz_proxy_error' );
?>
<div class="rootz-viewer-card">
    <div class="rootz-viewer-card-header">
        <h3>
            <span class="rootz-viewer-icon">&#129302;</span>
            <?php esc_html_e( 'AI Content Generation', 'rootz-ai-discovery' ); ?>
        </h3>
        <?php if ( $has_proxy ) : ?>
            <span class="rootz-status-connected">&#9679; <?php esc_html_e( 'Rootz AI Active', 'rootz-ai-discovery' ); ?></span>
        <?php elseif ( $has_direct ) : ?>
            <span class="rootz-status-connected">&#9679; <?php esc_html_e( 'Direct API', 'rootz-ai-discovery' ); ?></span>
        <?php else : ?>
            <span class="rootz-status-disconnected">&#9679; <?php esc_html_e( 'Not Available', 'rootz-ai-discovery' ); ?></span>
        <?php endif; ?>
    </div>

    <?php if ( $has_proxy ) : ?>
    <p class="rootz-viewer-explain">
        <?php esc_html_e( 'AI generation is powered by your plugin wallet. Requests are signed with your site key and processed through the Rootz AI service. No API key needed.', 'rootz-ai-discovery' ); ?>
    </p>

    <?php if ( $proxy_usage ) : ?>
    <div style="margin: 12px 0; padding: 12px 16px; background: #f0f6fc; border-radius: 4px; border-left: 3px solid #2271b1;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span>
                <strong><?php esc_html_e( 'Usage:', 'rootz-ai-discovery' ); ?></strong>
                <?php
                $used  = intval( $proxy_usage['used'] ?? 0 );
                $limit = intval( $proxy_usage['limit'] ?? 3 );
                $tier  = esc_html( $proxy_usage['tier'] ?? 'free' );
                printf(
                    esc_html__( '%1$d of %2$d generations this month', 'rootz-ai-discovery' ),
                    $used,
                    $limit
                );
                ?>
            </span>
            <span class="rootz-viewer-tag"><?php echo $tier; ?></span>
        </div>
        <?php if ( $limit > 0 ) : ?>
        <div style="margin-top: 8px; background: #ddd; border-radius: 3px; height: 6px; overflow: hidden;">
            <div style="background: <?php echo $used >= $limit ? '#d63638' : '#2271b1'; ?>; height: 100%; width: <?php echo min( 100, ( $used / $limit ) * 100 ); ?>%; border-radius: 3px;"></div>
        </div>
        <?php endif; ?>
        <?php if ( $used >= $limit && $tier === 'free' ) : ?>
        <p style="margin: 8px 0 0; font-size: 12px;">
            <a href="https://rootz.global/pricing" target="_blank" rel="noopener"><?php esc_html_e( 'Upgrade for more generations', 'rootz-ai-discovery' ); ?></a>
        </p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ( $proxy_error ) : ?>
    <div class="rootz-viewer-hint" style="border-left-color: #d63638; background: #fcf0f1;">
        <?php echo esc_html( $proxy_error ); ?>
    </div>
    <?php delete_transient( 'rootz_proxy_error' ); ?>
    <?php endif; ?>

    <?php elseif ( ! $has_proxy && ! $has_direct ) : ?>
    <p class="rootz-viewer-explain">
        <?php if ( ! empty( $signing_address ) && ! $has_gmp ) : ?>
            <?php esc_html_e( 'AI generation requires the GMP extension for wallet signing. Enable GMP on your host, or add your own Anthropic API key below as a fallback.', 'rootz-ai-discovery' ); ?>
        <?php elseif ( empty( $signing_address ) ) : ?>
            <?php esc_html_e( 'Generate a plugin wallet above to enable free AI-powered content generation, or add your own Anthropic API key below.', 'rootz-ai-discovery' ); ?>
        <?php endif; ?>
    </p>
    <?php endif; ?>

    <?php // Advanced: Direct API key ─────────────────────────────────── ?>
    <details style="margin-top: 12px;"<?php echo ! $has_proxy && $has_direct ? ' open' : ''; ?>>
        <summary style="cursor: pointer; font-size: 13px; color: #2271b1;">
            <?php esc_html_e( 'Advanced: Use your own Anthropic API key', 'rootz-ai-discovery' ); ?>
            <?php if ( $has_direct ) : ?>
                <span class="rootz-viewer-tag" style="margin-left: 6px;"><?php esc_html_e( 'configured', 'rootz-ai-discovery' ); ?></span>
            <?php endif; ?>
        </summary>
        <div style="margin-top: 12px; padding: 12px; background: #f9f9f9; border-radius: 4px;">
            <p class="description" style="margin-bottom: 8px;">
                <?php esc_html_e( 'Optional fallback. If the Rootz AI service is unavailable, the plugin will use this key to call Anthropic directly.', 'rootz-ai-discovery' ); ?>
            </p>
            <form method="post" action="options.php">
                <?php settings_fields( 'rootz_ai_discovery' ); ?>
                <table class="form-table" role="presentation" style="margin: 0;">
                    <tr style="padding: 0;">
                        <td style="padding: 4px 0;">
                            <input type="password" id="rootz_ai_api_key" name="rootz_ai_api_key"
                                   value="<?php echo esc_attr( $ai_api_key ); ?>"
                                   class="regular-text" placeholder="sk-ant-..." autocomplete="off" />
                        </td>
                    </tr>
                </table>
                <?php submit_button( __( 'Save API Key', 'rootz-ai-discovery' ), 'secondary', 'submit', false ); ?>
            </form>
        </div>
    </details>
</div>

<?php // ── AUTO-POPULATE ───────────────────────────────────────────────── ?>
<div class="rootz-viewer-card">
    <div class="rootz-viewer-card-header">
        <h3>
            <span class="rootz-viewer-icon">&#9889;</span>
            <?php esc_html_e( 'Auto-Populate from Site Data', 'rootz-ai-discovery' ); ?>
        </h3>
    </div>
    <p class="rootz-viewer-explain">
        <?php if ( $ai_available ) : ?>
            <?php esc_html_e( 'AI-powered auto-populate is active. Click below to have AI analyze your site content and generate polished AI Discovery fields.', 'rootz-ai-discovery' ); ?>
        <?php else : ?>
            <?php esc_html_e( 'Reads your existing WordPress content and pre-fills AI Discovery fields. Generate a plugin wallet or add an API key above for AI-enhanced generation.', 'rootz-ai-discovery' ); ?>
        <?php endif; ?>
    </p>

    <?php if ( $auto_populate ) : ?>
    <div class="rootz-viewer-hint" style="border-left-color: #00a32a; background: #f0faf0;">
        <?php esc_html_e( 'Auto-populate complete! Check the Identity tab to review the generated content.', 'rootz-ai-discovery' ); ?>
    </div>
    <?php endif; ?>

    <div id="rootz-auto-populate-preview" style="margin: 16px 0;">
        <?php
        $site_name  = get_bloginfo( 'name' );
        $site_desc  = get_bloginfo( 'description' );
        $about_page = null;
        foreach ( array( 'about', 'about-us', 'who-we-are' ) as $slug ) {
            $p = get_page_by_path( $slug );
            if ( $p && 'publish' === $p->post_status ) {
                $about_page = $p;
                break;
            }
        }
        $categories = get_categories( array( 'orderby' => 'count', 'order' => 'DESC', 'number' => 10, 'hide_empty' => true, 'exclude' => array( 1 ) ) );
        $page_count = wp_count_posts( 'page' )->publish;
        $post_count = wp_count_posts( 'post' )->publish;
        $has_woo    = class_exists( 'WooCommerce' );
        ?>

        <table class="rootz-viewer-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Data Source', 'rootz-ai-discovery' ); ?></th>
                    <th><?php esc_html_e( 'Found', 'rootz-ai-discovery' ); ?></th>
                    <th><?php esc_html_e( 'Will Populate', 'rootz-ai-discovery' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php esc_html_e( 'Site Title', 'rootz-ai-discovery' ); ?></td>
                    <td><strong><?php echo esc_html( $site_name ); ?></strong></td>
                    <td><?php esc_html_e( 'Organization Name', 'rootz-ai-discovery' ); ?></td>
                </tr>
                <tr>
                    <td><?php esc_html_e( 'Site Tagline', 'rootz-ai-discovery' ); ?></td>
                    <td><?php echo esc_html( $site_desc ?: '(empty)' ); ?></td>
                    <td><?php esc_html_e( 'Mission / Tagline', 'rootz-ai-discovery' ); ?></td>
                </tr>
                <tr>
                    <td><?php esc_html_e( 'About Page', 'rootz-ai-discovery' ); ?></td>
                    <td>
                        <?php if ( $about_page ) : ?>
                            <span style="color: #00a32a;">&#10003;</span> <?php echo esc_html( $about_page->post_title ); ?>
                        <?php else : ?>
                            <span style="color: #996800;">&#10007;</span> <?php esc_html_e( 'Not found', 'rootz-ai-discovery' ); ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ( $ai_available ) : ?>
                            <?php esc_html_e( 'AI Summary (AI-drafted from page content)', 'rootz-ai-discovery' ); ?>
                        <?php else : ?>
                            <?php esc_html_e( 'AI Summary (first 80 words of about page)', 'rootz-ai-discovery' ); ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td><?php esc_html_e( 'Categories', 'rootz-ai-discovery' ); ?></td>
                    <td><?php echo esc_html( count( $categories ) ); ?> <?php esc_html_e( 'categories', 'rootz-ai-discovery' ); ?></td>
                    <td><?php esc_html_e( 'Core Concepts / Glossary', 'rootz-ai-discovery' ); ?></td>
                </tr>
                <tr>
                    <td><?php esc_html_e( 'Pages', 'rootz-ai-discovery' ); ?></td>
                    <td><?php echo esc_html( $page_count ); ?> <?php esc_html_e( 'published', 'rootz-ai-discovery' ); ?></td>
                    <td><?php esc_html_e( 'Site map + Knowledge base', 'rootz-ai-discovery' ); ?></td>
                </tr>
                <tr>
                    <td><?php esc_html_e( 'Posts', 'rootz-ai-discovery' ); ?></td>
                    <td><?php echo esc_html( $post_count ); ?> <?php esc_html_e( 'published', 'rootz-ai-discovery' ); ?></td>
                    <td><?php esc_html_e( 'AI Feed', 'rootz-ai-discovery' ); ?></td>
                </tr>
                <?php if ( $has_woo ) : ?>
                <tr>
                    <td><?php esc_html_e( 'WooCommerce', 'rootz-ai-discovery' ); ?></td>
                    <td><span style="color: #00a32a;">&#10003;</span> <?php esc_html_e( 'Detected', 'rootz-ai-discovery' ); ?></td>
                    <td><?php esc_html_e( 'Products, pricing, inventory (future)', 'rootz-ai-discovery' ); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <form method="post" action="">
        <?php wp_nonce_field( 'rootz_auto_populate', 'rootz_auto_populate_nonce' ); ?>
        <p>
            <button type="submit" name="rootz_do_auto_populate" value="1" class="button button-primary">
                <?php if ( $ai_available ) : ?>
                    <?php esc_html_e( 'Auto-Populate with AI', 'rootz-ai-discovery' ); ?>
                <?php else : ?>
                    <?php esc_html_e( 'Auto-Populate from Site Data', 'rootz-ai-discovery' ); ?>
                <?php endif; ?>
            </button>
            <span class="description" style="margin-left: 12px;">
                <?php esc_html_e( 'Won\'t overwrite fields you\'ve already filled in.', 'rootz-ai-discovery' ); ?>
            </span>
        </p>
    </form>
</div>

<?php // ── SEO TAGS ────────────────────────────────────────────────────── ?>
<div class="rootz-viewer-card">
    <div class="rootz-viewer-card-header">
        <h3>
            <span class="rootz-viewer-icon">&#128270;</span>
            <?php esc_html_e( 'SEO Meta Tags', 'rootz-ai-discovery' ); ?>
        </h3>
    </div>
    <p class="rootz-viewer-explain">
        <?php esc_html_e( 'When enabled, the plugin adds a meta description, OpenGraph tags, and JSON-LD Organization schema to your site\'s HTML head. These are automatically skipped if a dedicated SEO plugin (Yoast, RankMath, AIOSEO, SEOPress) is detected.', 'rootz-ai-discovery' ); ?>
    </p>
    <form method="post" action="options.php">
        <?php settings_fields( 'rootz_ai_discovery' ); ?>
        <label style="display: flex; align-items: center; gap: 8px; padding: 8px 0;">
            <input type="hidden" name="rootz_enable_seo_tags" value="0" />
            <input type="checkbox" name="rootz_enable_seo_tags" value="1"
                   <?php checked( '1', get_option( 'rootz_enable_seo_tags', '1' ) ); ?> />
            <?php esc_html_e( 'Add meta description, OpenGraph, and JSON-LD when no SEO plugin is detected', 'rootz-ai-discovery' ); ?>
        </label>
        <?php submit_button( __( 'Save', 'rootz-ai-discovery' ), 'secondary', 'submit', false ); ?>
    </form>
</div>

<?php // ── SERVICE TIERS ─────────────────────────────────────────────── ?>
<div class="rootz-viewer-card">
    <div class="rootz-viewer-card-header">
        <h3>
            <span class="rootz-viewer-icon">&#11088;</span>
            <?php esc_html_e( 'Service Tiers', 'rootz-ai-discovery' ); ?>
        </h3>
    </div>

    <table class="widefat striped" style="max-width: 700px;">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Feature', 'rootz-ai-discovery' ); ?></th>
                <th><?php esc_html_e( 'Free', 'rootz-ai-discovery' ); ?></th>
                <th><?php esc_html_e( 'Starter', 'rootz-ai-discovery' ); ?></th>
                <th><?php esc_html_e( 'Agency', 'rootz-ai-discovery' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php esc_html_e( 'AI Discovery endpoints', 'rootz-ai-discovery' ); ?></td>
                <td>&#10003;</td>
                <td>&#10003;</td>
                <td>&#10003;</td>
            </tr>
            <tr>
                <td><?php esc_html_e( 'Cryptographic signing', 'rootz-ai-discovery' ); ?></td>
                <td><?php esc_html_e( 'Self-signed', 'rootz-ai-discovery' ); ?></td>
                <td><?php esc_html_e( 'Wallet-delegated', 'rootz-ai-discovery' ); ?></td>
                <td><?php esc_html_e( 'Wallet-delegated', 'rootz-ai-discovery' ); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e( 'AI auto-populate', 'rootz-ai-discovery' ); ?></td>
                <td><?php esc_html_e( 'Basic', 'rootz-ai-discovery' ); ?></td>
                <td>10/<?php esc_html_e( 'mo', 'rootz-ai-discovery' ); ?></td>
                <td>100/<?php esc_html_e( 'mo', 'rootz-ai-discovery' ); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e( 'Scanner & score tracking', 'rootz-ai-discovery' ); ?></td>
                <td>1 <?php esc_html_e( 'site', 'rootz-ai-discovery' ); ?></td>
                <td>1 <?php esc_html_e( 'site', 'rootz-ai-discovery' ); ?></td>
                <td>50 <?php esc_html_e( 'sites', 'rootz-ai-discovery' ); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e( 'Manifest anchoring', 'rootz-ai-discovery' ); ?></td>
                <td>&#10007;</td>
                <td>&#10003;</td>
                <td>&#10003;</td>
            </tr>
        </tbody>
    </table>

    <p style="margin-top: 12px;">
        <a href="https://rootz.global/pricing" target="_blank" rel="noopener" class="button">
            <?php esc_html_e( 'View Plans', 'rootz-ai-discovery' ); ?>
        </a>
    </p>
</div>
